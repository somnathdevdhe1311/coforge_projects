package com.santander.coforge.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SantanderPreparationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SantanderPreparationApplication.class, args);
	}

}
